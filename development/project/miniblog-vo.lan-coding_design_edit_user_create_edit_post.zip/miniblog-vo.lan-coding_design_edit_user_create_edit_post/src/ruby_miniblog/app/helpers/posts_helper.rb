module PostsHelper

def date_format(date)
   date.strftime("%d/%m/%Y %I:%M")

end
end
