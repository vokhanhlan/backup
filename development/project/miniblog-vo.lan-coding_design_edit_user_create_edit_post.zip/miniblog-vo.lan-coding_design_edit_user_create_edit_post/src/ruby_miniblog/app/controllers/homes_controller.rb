class HomesController < ApplicationController

end