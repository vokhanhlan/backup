# Be sure to restart your server when you modify this file.

CountriesDemo::Application.config.session_store :cookie_store, key: '_countries-demo_session'
