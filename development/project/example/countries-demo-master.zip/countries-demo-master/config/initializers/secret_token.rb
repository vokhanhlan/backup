# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
CountriesDemo::Application.config.secret_key_base = 'b93dd04b93dd786d0befe2054dffdcff16ba65059b5848d39a13061a1c64ee9db2124f4d19ec075f09a19168f5ebf8ef1b73bacbaf2eddd9be94740ab03c0cb9'
