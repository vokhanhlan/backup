require 'test_helper'

class LoaiSanPhamTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
