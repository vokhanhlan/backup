require 'test_helper'

class NguoidungTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
