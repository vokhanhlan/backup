require 'test_helper'

class NhaCungCapTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
