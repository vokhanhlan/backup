require 'test_helper'

class LoaiSanPhamsHelperTest < ActionView::TestCase
end
