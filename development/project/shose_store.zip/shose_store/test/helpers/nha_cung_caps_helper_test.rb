require 'test_helper'

class NhaCungCapsHelperTest < ActionView::TestCase
end
