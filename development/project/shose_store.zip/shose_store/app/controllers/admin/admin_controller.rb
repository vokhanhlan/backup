class Admin::AdminController < ApplicationController
  layout "application_v1"
  
end